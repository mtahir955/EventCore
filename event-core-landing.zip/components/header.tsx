"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

export function Header() {
  return (
    <header className="bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 px-6 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Image src="/images/ec-logo.png" alt="Event Core" width={48} height={48} className="rounded-lg" />
        </div>

        <nav className="hidden md:flex items-center space-x-12">
          <Link href="#" className="text-[#D19537] font-medium border-b-2 border-[#D19537] pb-1 transition-colors">
            Home
          </Link>
          <Link
            href="#"
            className="text-gray-700 dark:text-white hover:text-[#D19537] dark:hover:text-[#D19537] font-medium transition-colors"
          >
            Events
          </Link>
          <Link
            href="#"
            className="text-gray-700 dark:text-white hover:text-[#D19537] dark:hover:text-[#D19537] font-medium transition-colors"
          >
            About
          </Link>
          <Link
            href="#"
            className="text-gray-700 dark:text-white hover:text-[#D19537] dark:hover:text-[#D19537] font-medium transition-colors"
          >
            Trainers
          </Link>
          <Link
            href="#"
            className="text-gray-700 dark:text-white hover:text-[#D19537] dark:hover:text-[#D19537] font-medium transition-colors"
          >
            Calendar
          </Link>
        </nav>

        <div className="flex items-center space-x-6">
          <ThemeToggle />
          <Link
            href="#"
            className="text-gray-700 dark:text-white hover:text-[#D19537] dark:hover:text-[#D19537] font-medium transition-colors"
          >
            Login
          </Link>
          <Button className="bg-[#D19537] hover:bg-[#B8832F] text-white px-8 py-2 rounded-full font-medium">
            Start Now
          </Button>
        </div>
      </div>
    </header>
  )
}
