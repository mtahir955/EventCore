"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export function ContactSection() {
  return (
    <section className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-6">
        <div className="space-y-4 mb-12">
          <div className="inline-flex items-center space-x-2 bg-[#D19537] rounded-full px-4 py-2">
            <div className="w-2 h-2 bg-white rounded-full" />
            <span className="text-white text-sm font-medium">Get Started</span>
          </div>

          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white">
            <span className="text-[#D19537] italic">Get in touch</span> with us. We're here to assist you.
          </h2>
        </div>

        <form className="grid md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">Full Name</label>
              <Input
                placeholder="Enter Your Name"
                className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">Phone Number</label>
              <Input
                placeholder="Enter Your Number"
                className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400"
              />
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">Company Name</label>
              <Input
                placeholder="Enter Your Company Name"
                className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">Email</label>
              <Input
                placeholder="Enter Your Email"
                type="email"
                className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400"
              />
            </div>
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-900 dark:text-white mb-2">Message</label>
            <Textarea
              placeholder="Start Typing Your Message"
              rows={6}
              className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400 resize-none"
            />
          </div>

          <div className="md:col-span-2">
            <Button className="bg-[#D19537] hover:bg-[#B8832F] text-white px-8 py-3 rounded-full">
              Leave us a Message
            </Button>
          </div>
        </form>
      </div>
    </section>
  )
}
