"use client"

import { Button } from "@/components/ui/button"
import { Play } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 dark:from-gray-900 dark:via-gray-800 dark:to-black overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-black/40 dark:bg-black/60 z-10" />
        <img src="/images/business-meeting.jpg" alt="Professional meeting" className="w-full h-full object-cover" />
      </div>

      {/* Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 pt-32 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          <div className="space-y-8">
            <div className="inline-flex items-center space-x-2 bg-black/50 backdrop-blur-sm rounded-full px-4 py-2 border border-white/20">
              <div className="w-2 h-2 bg-[#D19537] rounded-full" />
              <span className="text-white text-sm font-medium">Event Core Solutions</span>
            </div>

            {/* Main Heading */}
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">At the Core of every</h1>
              <h1 className="text-5xl lg:text-6xl font-bold text-[#D19537] italic leading-tight">Great Event</h1>
            </div>

            {/* CTA Button */}
            <Button className="bg-white text-black hover:bg-gray-100 px-8 py-3 rounded-full text-lg font-semibold">
              Get Started
            </Button>
          </div>

          <div className="relative">
            {/* Video Preview Card */}
            <div className="relative bg-black/30 backdrop-blur-sm rounded-2xl p-6 space-y-4 border border-white/20">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-[#D19537] rounded-full" />
                <span className="text-white text-sm font-medium">Next Event</span>
              </div>

              <div className="relative aspect-video bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl overflow-hidden">
                <img src="/images/modern-venue.jpg" alt="Event preview" className="w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button size="lg" className="bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full p-4">
                    <Play className="h-6 w-6 text-white" />
                  </Button>
                </div>
              </div>

              <div className="text-white">
                <h3 className="font-semibold">Watch Video</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
