"use client"

import { Button } from "@/components/ui/button"

export function CTASection() {
  return (
    <section className="relative py-32 bg-black dark:bg-gray-900 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-black/60 dark:bg-black/70 z-10" />
        <img src="/images/smiling-man.jpg" alt="Professional background" className="w-full h-full object-cover" />
      </div>

      {/* Content */}
      <div className="relative z-20 max-w-4xl mx-auto px-6 text-center">
        <div className="space-y-8">
          <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
            Achieve balance, growth,
            <br />
            and mastery in life
          </h2>

          <p className="text-lg text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Close the gap between where you are and where you want to be through inspiring, life-changing speaking.
          </p>

          <Button className="bg-white text-black hover:bg-gray-100 px-8 py-3 rounded-full text-lg font-semibold">
            Get Started
          </Button>
        </div>
      </div>
    </section>
  )
}
